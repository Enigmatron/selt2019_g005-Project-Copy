# SELT 2019 GROUP `005` - MY PROJECT TITLE

We are building a modernized anonymous, geo-locked social media platform. 

## Project Team
  - Donovan Schroeder (319) 217-2131 donovan-schroeder@uiowa.edu - 
  - Stjepan Fiolic (Steve) (515) 778-5187 stjepan-fiolic@uiowa.edu - sfiolic - 01184781
  - Idries Kysia (773) 490-6400 iykysia@uiowa.edu - 01225904
  - Chibuzo Nwakama (507) 829-5432 chibuzo-nwakama@uiowa.edu - 01207608 (cnwakama)
  - Alan Penze (779) 537-2700 alan-penze@uiowa.edu - 00976532
## Installation Guide

This project uses ruby v2.5.5  on rails version 4.2.10 in a heroku deployment with a PostgreSQL database.

## Resource Links

https://devcenter.heroku.com/categories/ruby-support


## Other stuff useful for understanding the project from a developers standpoint.

[pivotal tracker](https://www.pivotaltracker.com/n/projects/2408293)
