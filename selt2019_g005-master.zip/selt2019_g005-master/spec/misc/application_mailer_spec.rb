# frozen_string_literal: true

require 'spec_helper'
require 'rails_helper'
require 'application_mailer.rb'

# RSpec.describe ApplicationMailer, type: :mail do
#   describe 'Creation Tests' do
#
#       it 'succeeds' do
#         expect(ApplicationMailer.instance_variable_get :from).to eq('from@example.com')
#       end
#     end
# end
